//
//  BaseViewModel.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/28/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import RxSwift

/**
 A common ViewModel class
 */
class BaseViewModel {
    
    /// Base output state
    struct BaseOutput {
        let alert : PublishSubject<String>
        let loading : PublishSubject<Bool>
    }
    
    /// DisposeBag for observable
    let disposeBag = DisposeBag()
    
    /// BaseOutput
    let base:BaseOutput
    
    init() {
        base = BaseOutput(alert: PublishSubject<String>(), loading: PublishSubject<Bool>())
    }
    
    /// show/hide loading
    func loading(_ show:Bool) {
        base.loading.onNext(show)
    }
    
    func alert(_ message:String) {
        base.alert.onNext(message)
    }
}

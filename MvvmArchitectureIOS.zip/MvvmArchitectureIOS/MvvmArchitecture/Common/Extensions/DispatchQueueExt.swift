//
//  DispatchQueueExt.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/5/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import Foundation

typealias Dispatch = DispatchQueue

extension Dispatch {
    
    /// Do task in background thread
    static func background(_ task: @escaping () -> ()) {
        Dispatch.global(qos: .background).async {
            task()
        }
    }
    
    /// Do task in main thread
    static func main(_ task: @escaping () -> ()) {
        Dispatch.main.async {
            task()
        }
    }
}

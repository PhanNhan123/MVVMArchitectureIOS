//
//  ImageExt.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/31/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import UIKit
import Nuke

extension UIImageView {
    
    /// Use Nuke library to load image by url
    func loadUrl(_ url: String?) {
        Nuke.loadImage(with: URL(string: url!)!, into: self)
    }
}




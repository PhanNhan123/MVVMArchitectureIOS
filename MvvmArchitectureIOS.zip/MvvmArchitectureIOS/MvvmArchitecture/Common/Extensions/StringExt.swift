//
//  StringExt.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/21/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation

extension String {
    
    /// Initializes an NSURL object with a provided URL string. 
    var url: URL? {
        return URL(string: self)
    }
}

//
//  AppConstants.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/21/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

/**
 Put app contants here
 */
struct App {
    
}

struct Facebook {
    static let TOKEN : String = "ABC@1234XYZ$%^&*"
}

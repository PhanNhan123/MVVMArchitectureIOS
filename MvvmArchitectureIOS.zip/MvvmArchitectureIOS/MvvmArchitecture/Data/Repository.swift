//
//  BaseManager.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/28/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation

/// Data manager
/// Call to get data from APIs, Database, UserDefaults, Files...
class Repository {}

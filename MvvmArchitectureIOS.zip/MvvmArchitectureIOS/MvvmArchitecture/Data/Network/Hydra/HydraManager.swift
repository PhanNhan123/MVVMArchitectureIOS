//
//  HydraManager.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/12/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import Foundation
import AppAuth

/// Connect to hydra server manager
class HydraManager {
    
    /// define hydra constants here
    enum OAuth {
        static let authorizationEndpoint = URL(string: "http://172.18.4.104:4444/oauth2/auth")!
        static let tokenEndpoint = URL(string: "http://172.18.4.104:4444/oauth2/token")!
        static let clientID = "auth-code-client"
        static let redirectURI = URL(string: "hitachi://authorize")!
    }
    
    /// single object
    static let shared = HydraManager()
    
    /// configuration of authorization endpoint & token endpoint
    let configuration : OIDServiceConfiguration
    
    init() {
        configuration = OIDServiceConfiguration(authorizationEndpoint: OAuth.authorizationEndpoint,
                                                tokenEndpoint: OAuth.tokenEndpoint)
    }
    
    func authorize(vc:UIViewController) {
    }
}

//
//  UserManager.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/21/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation
import RxSwift

class UserRepository: Repository {
    
    static let shared = UserRepository()
    
    private let userService:UserServiceProtocol
    
    override init() {
        self.userService = UserService()
    }
    
    func getUsers(since:String) -> Observable<[User]> {
        return userService.getUsers(since: since)
    }
    
    func getUser(username:String) -> Observable<User> {
        return userService.getUser(username: username)
    }
    
    
}

//
//  UserDefaultsManager.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/28/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation

/**
 UserDefaultsManager to get/set UserDefaults values
 */
class UserDefaultsManager: NSObject {
    
    /// Define keys
    enum Key {
        static let USER_TOKEN = "key_token"
    }
    
    /// Get token from userdefaults
    static var token: String? {
        let data = UserDefaults.standard.string(forKey: Key.USER_TOKEN)
        return data
    }
    
    /// Set token from userdefaults
    static func setToken(_token : String) {
        UserDefaults.standard.removeObject(forKey: Key.USER_TOKEN)
    }
}

//
//  User.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/18/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation

/// User modal
struct User : Codable {
    var id : Int?
    var login : String?
    var avatarUrl : String?
    var url : String?
    var name : String?
    var location : String?
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case login = "login"
        case avatarUrl = "avatar_url"
        case url = "html_url"
        case name = "name"
        case location = "location"
    }
}

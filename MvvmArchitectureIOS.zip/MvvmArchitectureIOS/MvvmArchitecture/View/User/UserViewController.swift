//
//  UserViewController.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/4/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import UIKit
import RxSwift

class UserViewController: BaseViewController<UserViewModel> {
    
    static func create(user:User?) -> UserViewController {
        let view = UserViewController.instantiate()
        view.viewModel = UserViewModel(user: user)
        return view
    }
    
    @IBOutlet weak var avatarImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var linkButton: UIButton!
    
    private var userLink = ""
    
    override func setupUI() {
        super.setupUI()
    }
    @IBAction func touchLinkGithub(_ sender: Any) {
        navigator.safari(url: userLink)
    }
    
    override func setupViewModel() {
        super.setupViewModel()
        
        viewModel.base.loading
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] show in
                self?.showIndicator(show)
            }).disposed(by: disposeBag)
        
        viewModel.outUser
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] user in
                self?.loadUser(user)
            }).disposed(by: disposeBag)
        
    }
    
    override func setupData() {
        super.setupData()
        viewModel?.inReload.onNext(())
    }
    
    private func loadUser(_ user:User) {
        self.navigationItem.title = user.name
        nameLabel.text = user.login
        avatarImageView.loadUrl(user.avatarUrl)
        userLink = user.url ?? ""
    }
}

extension UserViewController: StoryboardInstantiable {}

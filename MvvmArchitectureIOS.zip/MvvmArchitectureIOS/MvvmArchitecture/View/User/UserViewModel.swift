//
//  UserViewModel.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/4/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import RxSwift

final class UserViewModel: BaseViewModel {
    
    let user : User!
    
    // MARK: - Inputs
    let inReload = PublishSubject<Void>()
    
    // MARK: - Outputs
    let outUser = PublishSubject<User>()
    
    init(user : User?) {
        self.user = user
        super.init()
        
        /// subscribe inputs here
        inReload.subscribe(onNext: { () in
            self.loadUser()
        }).disposed(by: disposeBag)
    }
    
    private func loadUser() {
        /// show loading
        loading(true)
        /// call request API
        UserRepository.shared.getUser(username: user.login!)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext : { [weak self] user in
                    self?.outUser.onNext(user)
                },
                onError: { [weak self] error in
                    self?.loading(false)
                    self?.alert(error.localizedDescription)
                },
                onCompleted: { [weak self] () in
                    self?.loading(false)
                }
        ).disposed(by: disposeBag)
        
    }
    
}

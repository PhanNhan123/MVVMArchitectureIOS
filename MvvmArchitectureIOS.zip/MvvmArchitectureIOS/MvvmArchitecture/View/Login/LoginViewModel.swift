
//
//  LoginViewModal.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/11/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import RxSwift

final class LoginViewModel: BaseViewModel {
    
    func authorize(vc:UIViewController) {
        HydraManager.shared.authorize(vc: vc)
    }
}

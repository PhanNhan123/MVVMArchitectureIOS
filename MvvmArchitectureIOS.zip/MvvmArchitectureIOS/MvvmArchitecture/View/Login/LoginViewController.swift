//
//  LoginViewController.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 1/11/21.
//  Copyright © 2021 Hitachi Vantara. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController<LoginViewModel> {
    
    @IBAction func touchAuthorize(_ sender: Any) {
        viewModel.authorize(vc: self)
    }
    
    override func setupViewModel() {
        super.setupViewModel()
        viewModel = LoginViewModel()
    }
}

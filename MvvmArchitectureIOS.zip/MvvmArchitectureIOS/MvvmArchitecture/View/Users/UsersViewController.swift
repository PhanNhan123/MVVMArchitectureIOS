//
//  UsersViewController.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/28/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import UIKit
import RxSwift

class UsersViewController: BaseViewController<UsersViewModel> {
    
    @IBOutlet weak var usersTableView: UITableView!
    
    override func setupUI() {
        super.setupUI()
        usersTableView.refreshControl = UIRefreshControl()
    }
    
    override func setupViewModel() {
        super.setupViewModel()
        viewModel = UsersViewModel()
        
        viewModel.base.loading
            .bind(to: (usersTableView.refreshControl?.rx.isRefreshing)!)
            .disposed(by: disposeBag)
        
        viewModel.outUsers
            .bind(to: usersTableView.rx.items(cellIdentifier: UserCell.reuseID, cellType: UserCell.self)) { index, user, cell in
                cell.bind(user: user)
        }.disposed(by: disposeBag)
        
        usersTableView.refreshControl?.rx
            .controlEvent(.valueChanged)
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] () in
                self?.viewModel?.inReload.onNext(())
            }).disposed(by: disposeBag)
        
        usersTableView.rx.modelSelected(User.self)
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { user in
                let vc = UserViewController.create(user: user)
                self.navigator.push(target: vc, sender: self)
            }).disposed(by: disposeBag)
    }
    
    override func setupData() {
        viewModel?.inReload.onNext(())
    }
}

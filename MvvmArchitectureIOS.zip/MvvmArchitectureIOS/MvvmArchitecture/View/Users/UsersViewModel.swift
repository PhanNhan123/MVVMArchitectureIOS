//
//  UsersViewModel.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/28/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import RxSwift

final class UsersViewModel: BaseViewModel {
    
    // MARK: - Inputs
    let inReload = PublishSubject<Void>()
    
    // MARK: - Outputs
    let outUsers = PublishSubject<[User]>()
    
    override init() {
        super.init()
        /// subscribe inputs here
        inReload.subscribe(onNext: { () in
            self.loadUsers()
        }).disposed(by: disposeBag)
    }
    
    private func loadUsers() {
        /// show loading
        loading(true)
        /// call request API
        UserRepository.shared.getUsers(since: "")
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext : { [weak self] users in
                    self?.outUsers.onNext(users)
                },
                onError: { [weak self] error in
                    self?.loading(false)
                    self?.alert(error.localizedDescription)
                },
                onCompleted: { [weak self] () in
                    self?.loading(false)
                }
        ).disposed(by: disposeBag)
        
    }
}

//
//  UserCell.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/31/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import UIKit

class UserCell: UITableViewCell {
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func bind(user:User) {
        nameLabel.text = user.login
        avatarImageView.loadUrl(user.avatarUrl)
    }
}

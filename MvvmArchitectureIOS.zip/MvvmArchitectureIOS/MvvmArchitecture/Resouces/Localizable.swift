//
//  Localizable.swift
//  MvvmArchitecture
//
//  Created by thinhlh on 12/31/20.
//  Copyright © 2020 Hitachi Vantara. All rights reserved.
//

import Foundation
import SwifterSwift

struct Localizable {
    static let error = "ERROR".localized()
    static let ok = "OK".localized()
}
